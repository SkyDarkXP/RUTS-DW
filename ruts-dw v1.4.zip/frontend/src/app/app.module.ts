import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { AdminComponent } from './pages/admin/admin.component';
import { ThreeBgComponent } from './components/three-bg/three-bg.component';
import { MovieRowComponent } from './components/movie-row/movie-row.component';
import { CourseDetailComponent } from './pages/course-detail/course-detail.component';
import { SearchComponent } from './pages/search/search.component';
import { FacultiesComponent } from './pages/faculties/faculties.component';
import { NotFoundComponent } from './pages/not-found/not-found.component';
import { AdminDashboardComponent } from './pages/admin-dashboard/admin-dashboard.component';
import { AdminUsersComponent } from './pages/admin-users/admin-users.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    AdminComponent,
    ThreeBgComponent,
    MovieRowComponent,
    CourseDetailComponent,
    SearchComponent,
    FacultiesComponent,
    NotFoundComponent,
    AdminDashboardComponent,
    AdminUsersComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}

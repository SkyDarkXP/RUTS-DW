#!/bin/sh
# entrypoint.sh — copy flows จาก source ทุกครั้งที่ container start
# ทำให้ flows.json ที่แก้ไขมีผลทันทีโดยไม่ต้องลบ volume

echo "[entrypoint] Copying flows.json from /flows_src/flows.json to /data/flows.json"
cp /flows_src/flows.json /data/flows.json

echo "[entrypoint] Starting Node-RED..."
exec node-red --settings /data/settings.js

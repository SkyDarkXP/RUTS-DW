module.exports = {
    flowFile: '/flows/flows.json',
    flowFilePretty: true,
    credentialSecret: process.env.NODE_RED_CREDENTIAL_SECRET || 'ruts_secret',
    uiPort: 1880,
    uiHost: '0.0.0.0',
    httpAdminRoot: '/nodered',
    httpNodeRoot: '/',
    adminAuth: {
        type: 'credentials',
        users: [{
            username: 'admin',
            password: '$2b$08$2PTrglavL02.1ogUH/jpEepFipEcjjkQkDWIiuO3ov6irtIQNbEBK',
            permissions: '*'
        }]
    },
    functionGlobalContext: {
        jwt: require('jsonwebtoken'),
        bcrypt: require('bcryptjs'),
        jwtSecret: process.env.JWT_SECRET || 'ruts_jwt_super_secret_2024',
        mysqlConfig: {
            host: process.env.MYSQL_HOST || 'mysql',
            port: parseInt(process.env.MYSQL_PORT || '3306'),
            user: process.env.MYSQL_USER || 'ruts_user',
            password: process.env.MYSQL_PASSWORD || 'ruts_password',
            database: process.env.MYSQL_DATABASE || 'ruts_db'
        }
    },
    logging: {
        console: {
            level: 'info',
            metrics: false,
            audit: false
        }
    },
    editorTheme: {
        page: { title: 'RUTS Course API - Node-RED' }
    },
    exportGlobalContextKeys: false,
    externalModules: {}
};

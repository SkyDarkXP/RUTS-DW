const http = require('http');

const TOKEN = process.argv[2];

const courses = [
  {
    faculty_id: 1,
    title_th: 'หลักสูตรอุตสาหกรรมศาสตรบัณฑิต สาขาวิชาเทคโนโลยีอุตสาหการ (ต่อเนื่อง)',
    title_en: 'Bachelor of Industrial Technology Program in Industrial Technology (Continuing Program)',
    degree_full_th: 'อุตสาหกรรมศาสตรบัณฑิต (เทคโนโลยีอุตสาหการ)',
    degree_abbr_th: 'อส.บ. (เทคโนโลยีอุตสาหการ)',
    degree_full_en: 'Bachelor of Industrial Technology (Industrial Technology)',
    degree_abbr_en: 'B. Ind. Tech. (Industrial Technology)',
    degree_th: 'ปริญญาตรี', degree_en: 'Bachelor', duration_years: 2, total_credits: 77, level: 'ปวส.',
    career_path: 'นักเทคโนโลยีปฏิบัติการในภาคอุตสาหกรรม\nเจ้าหน้าที่ของรัฐในหน่วยงานราชการที่เกี่ยวข้องกับเทคโนโลยีอุตสาหการ\nเจ้าหน้าที่ของรัฐในหน่วยงานรัฐวิสาหกิจ และองค์กรเอกชนที่เกี่ยวข้องกับเทคโนโลยีอุตสาหการ\nผู้สอนในสถาบันการศึกษา\nผู้เชี่ยวชาญหรือที่ปรึกษาด้านเทคโนโลยีอุตสาหการ\nผู้ประกอบการด้านเทคโนโลยีอุตสาหการ',
    program_format: 'รูปแบบ : หลักสูตรระดับปริญญาตรี (ต่อเนื่อง)\nประเภทของหลักสูตร : หลักสูตรปฏิบัติการ\nภาษาที่ใช้ : ภาษาไทยและภาษาอังกฤษ โดยใช้ภาษาอังกฤษไม่น้อยกว่าร้อยละ 50\nการรับเข้าศึกษา : นักศึกษาไทย และ/หรือ นักศึกษาต่างชาติ\nความร่วมมือกับสถาบันอื่น : เป็นหลักสูตรเฉพาะของมหาวิทยาลัย\nการให้ปริญญา : ให้ปริญญาเพียงสาขาวิชาเดียว',
    image_url: 'https://eng.rmutsv.ac.th/ruts/wp-content/uploads/2024/05/industrail-technology.jpg',
    is_active: true, is_featured: false, sort_order: 10
  },
  {
    faculty_id: 1,
    title_th: 'หลักสูตรวิศวกรรมศาสตรบัณฑิต สาขาวิชาวิศวกรรมการผลิต',
    title_en: 'Bachelor of Engineering Program in Production Engineering',
    degree_full_th: 'วิศวกรรมศาสตรบัณฑิต (วิศวกรรมการผลิต)',
    degree_abbr_th: 'วศ.บ. (วิศวกรรมการผลิต)',
    degree_full_en: 'Bachelor of Engineering (Production Engineering)',
    degree_abbr_en: 'B.Eng. (Production Engineering)',
    degree_th: 'ปริญญาตรี', degree_en: 'Bachelor', duration_years: 4, total_credits: 147, level: 'ปวช./ม.6',
    career_path: 'วิศวกรควบคุมระบบการผลิตในงานอุตสาหกรรม\nวิศวกรออกแบบและพัฒนาผลิตภัณฑ์\nวิศวกรควบคุมคุณภาพและประกันคุณภาพ\nวิศวกรโรงงานและวิศวกรโครงการ\nวิศวกรวางแผนการซ่อมบำรุง\nวิศวกรวิเคราะห์ระบบการผลิตของเครื่องจักรในโรงงาน\nผู้ประกอบการทางด้านวิศวกรรมการผลิตและนวัตกรรมชุมชน',
    program_format: 'รูปแบบ : หลักสูตรระดับปริญญาตรี หลักสูตร 4 ปี\nประเภทของหลักสูตร : หลักสูตรทางวิชาชีพ\nภาษาที่ใช้ : ภาษาไทยและภาษาอังกฤษ โดยใช้ภาษาอังกฤษไม่น้อยกว่าร้อยละ 50\nการรับเข้าศึกษา : รับนักศึกษาไทย และ/หรือ นักศึกษาต่างชาติที่เข้าใจภาษาไทยเป็นอย่างดี\nความร่วมมือกับสถาบันอื่น : เป็นหลักสูตรเฉพาะของมหาวิทยาลัย\nการให้ปริญญา : ให้ปริญญาเพียงสาขาวิชาเดียว',
    image_url: 'https://eng.rmutsv.ac.th/ruts/wp-content/uploads/2024/05/production.jpg',
    is_active: true, is_featured: false, sort_order: 20
  },
  {
    faculty_id: 1,
    title_th: 'หลักสูตรวิศวกรรมศาสตรบัณฑิต สาขาวิชาวิศวกรรมอุตสาหการ',
    title_en: 'Bachelor of Engineering Program in Industrial Engineering',
    degree_full_th: 'วิศวกรรมศาสตรบัณฑิต (วิศวกรรมอุตสาหการ)',
    degree_abbr_th: 'วศ.บ. (วิศวกรรมอุตสาหการ)',
    degree_full_en: 'Bachelor of Engineering (Industrial Engineering)',
    degree_abbr_en: 'B.Eng. (Industrial Engineering)',
    degree_th: 'ปริญญาตรี', degree_en: 'Bachelor', duration_years: 4, total_credits: 145, level: 'ปวช./ม.6',
    career_path: 'วิศวกรออกแบบและพัฒนาผลิตภัณฑ์\nวิศวกรวางแผนและควบคุมการผลิต\nวิศวกรการผลิตและกระบวนการผลิต\nวิศวกรควบคุมคุณภาพและประกันคุณภาพ\nวิศวกรโรงงานและวิศวกรโครงการ\nวิศวกรซ่อมบำรุง\nวิศวกรโลจิสติกส์\nวิศวกรจัดซื้อ\nวิศวกรประมาณราคาและวิเคราะห์ข้อมูลทางธุรกิจอุตสาหกรรม\nผู้ประกอบการทางด้านวิศวกรรมอุตสาหการและการผลิต',
    program_format: 'รูปแบบ : หลักสูตรระดับปริญญาตรี หลักสูตร 4 ปี\nประเภทของหลักสูตร : หลักสูตรทางวิชาชีพ\nภาษาที่ใช้ : ภาษาไทยและภาษาอังกฤษ โดยใช้ภาษาอังกฤษไม่น้อยกว่าร้อยละ 50\nการรับเข้าศึกษา : นักศึกษาไทย และ/หรือ นักศึกษาต่างชาติที่เข้าใจภาษาไทยเป็นอย่างดี\nความร่วมมือกับสถาบันอื่น : เป็นหลักสูตรเฉพาะของมหาวิทยาลัย\nการให้ปริญญา : ให้ปริญญาเพียงสาขาวิชาเดียว',
    image_url: 'https://eng.rmutsv.ac.th/ruts/wp-content/uploads/2024/05/industrial.jpg',
    is_active: true, is_featured: false, sort_order: 30
  },
  {
    faculty_id: 1,
    title_th: 'หลักสูตรวิศวกรรมศาสตรบัณฑิต สาขาวิชาวิศวกรรมไฟฟ้า',
    title_en: 'Bachelor of Engineering Program in Electrical Engineering',
    degree_full_th: 'วิศวกรรมศาสตรบัณฑิต (วิศวกรรมไฟฟ้า)',
    degree_abbr_th: 'วศ.บ. (วิศวกรรมไฟฟ้า)',
    degree_full_en: 'Bachelor of Engineering (Electrical Engineering)',
    degree_abbr_en: 'B.Eng. (Electrical Engineering)',
    degree_th: 'ปริญญาตรี', degree_en: 'Bachelor', duration_years: 4, total_credits: 147, level: 'ปวช./ม.6',
    career_path: 'วิศวกรไฟฟ้าในสถานประกอบการทั้งภาครัฐและเอกชน\nผู้ประกอบกิจการด้านวิศวกรรมไฟฟ้า\nวิศวกรไฟฟ้าระบบควบคุมในงานอุตสาหกรรมยานยนต์ไฟฟ้าและระบบราง\nนักวิชาการด้านวิศวกรรมไฟฟ้าในหน่วยงานของภาครัฐและเอกชน',
    program_format: 'รูปแบบ : หลักสูตรระดับปริญญาตรี หลักสูตร 4 ปี\nประเภทของหลักสูตร : หลักสูตรทางวิชาชีพ\nภาษาที่ใช้ : ภาษาไทยและภาษาอังกฤษ โดยใช้ภาษาอังกฤษไม่น้อยกว่าร้อยละ 50\nการรับเข้าศึกษา : รับนักศึกษาไทย และ/หรือ นักศึกษาต่างชาติที่เข้าใจภาษาไทยเป็นอย่างดี\nความร่วมมือกับสถาบันอื่น : เป็นหลักสูตรเฉพาะของมหาวิทยาลัย\nการให้ปริญญา : ให้ปริญญาเพียงสาขาวิชาเดียว',
    image_url: 'https://eng.rmutsv.ac.th/ruts/wp-content/uploads/2024/05/electrical.jpg',
    is_active: true, is_featured: false, sort_order: 40
  },
  {
    faculty_id: 1,
    title_th: 'หลักสูตรวิศวกรรมศาสตรบัณฑิต สาขาวิชาวิศวกรรมอิเล็กทรอนิกส์',
    title_en: 'Bachelor of Engineering Program in Electronics Engineering',
    degree_full_th: 'วิศวกรรมศาสตรบัณฑิต (วิศวกรรมอิเล็กทรอนิกส์)',
    degree_abbr_th: 'วศ.บ. (วิศวกรรมอิเล็กทรอนิกส์)',
    degree_full_en: 'Bachelor of Engineering (Electronics Engineering)',
    degree_abbr_en: 'B.Eng. (Electronics Engineering)',
    degree_th: 'ปริญญาตรี', degree_en: 'Bachelor', duration_years: 4, total_credits: 127, level: 'ปวช./ม.6',
    career_path: 'เจ้าของสถานประกอบการด้านไฟฟ้าอิเล็กทรอนิกส์\nที่ปรึกษาด้านวิศวกรรมอิเล็กทรอนิกส์\nนักวิจัยหรือนักวิชาการในหน่วยงานของภาครัฐและเอกชน\nวิศวกรในหน่วยงานราชการต่างๆ\nวิศวกรในหน่วยงานรัฐวิสาหกิจ\nวิศวกรในสถานประกอบการ/บริษัทเอกชน\nผู้ดูแลระบบงานเทคนิคและซ่อมบำรุงด้านไฟฟ้าอิเล็กทรอนิกส์\nเจ้าหน้าที่ประจำห้องปฏิบัติการ',
    program_format: 'รูปแบบ : หลักสูตรระดับปริญญาตรี หลักสูตร 4 ปี\nประเภทของหลักสูตร : หลักสูตรทางวิชาชีพ\nภาษาที่ใช้ : ภาษาไทยและภาษาอังกฤษ โดยใช้ภาษาอังกฤษไม่น้อยกว่าร้อยละ 50 ของทุกรายวิชาในหมวดวิชาเฉพาะ\nการรับเข้าศึกษา : รับนักศึกษาไทย และ/หรือ นักศึกษาต่างชาติที่เข้าใจภาษาไทยเป็นอย่างดี\nความร่วมมือกับสถาบันอื่น : เป็นหลักสูตรเฉพาะของมหาวิทยาลัย โดยมีความร่วมมือกับ บริษัท กสท โทรคมนาคม จำกัด\nการให้ปริญญา : ให้ปริญญาเพียงสาขาวิชาเดียว',
    image_url: 'https://eng.rmutsv.ac.th/ruts/wp-content/uploads/2024/05/electronics.jpg',
    is_active: true, is_featured: false, sort_order: 50
  },
  {
    faculty_id: 1,
    title_th: 'หลักสูตรวิศวกรรมศาสตรบัณฑิต สาขาวิชาวิศวกรรมเครื่องกล',
    title_en: 'Bachelor of Engineering Program in Mechanical Engineering',
    degree_full_th: 'วิศวกรรมศาสตรบัณฑิต (วิศวกรรมเครื่องกล)',
    degree_abbr_th: 'วศ.บ. (วิศวกรรมเครื่องกล)',
    degree_full_en: 'Bachelor of Engineering (Mechanical Engineering)',
    degree_abbr_en: 'B.Eng. (Mechanical Engineering)',
    degree_th: 'ปริญญาตรี', degree_en: 'Bachelor', duration_years: 4, total_credits: 145, level: 'ปวช./ม.6',
    career_path: 'วิศวกรโครงการ\nวิศวกรโรงงาน\nวิศวกรเครื่องกลในหน่วยงานราชการและรัฐวิสาหกิจ\nวิศวกรผู้รับผิดชอบด้านพลังงาน\nวิศวกรออกแบบและพัฒนา\nผู้ประกอบการ\nผู้จัดการโรงงาน\nนักวิจัย',
    program_format: 'รูปแบบ : หลักสูตรระดับปริญญาตรี หลักสูตร 4 ปี\nประเภทของหลักสูตร : หลักสูตรทางวิชาชีพ\nภาษาที่ใช้ : ภาษาไทยและภาษาอังกฤษ โดยใช้ภาษาอังกฤษไม่น้อยกว่าร้อยละ 50\nการรับเข้าศึกษา : นักศึกษาไทย และ/หรือ นักศึกษาต่างชาติ\nความร่วมมือกับสถาบันอื่น : เป็นหลักสูตรเฉพาะของมหาวิทยาลัย\nการให้ปริญญา : ให้ปริญญาเพียงสาขาวิชาเดียว',
    image_url: 'https://eng.rmutsv.ac.th/ruts/wp-content/uploads/2024/05/mechanical.jpg',
    is_active: true, is_featured: false, sort_order: 60
  },
  {
    faculty_id: 1,
    title_th: 'หลักสูตรวิศวกรรมศาสตรบัณฑิต สาขาวิชาวิศวกรรมเครื่องกลเรือ',
    title_en: 'Bachelor of Engineering Program in Marine Engineering',
    degree_full_th: 'วิศวกรรมศาสตรบัณฑิต (วิศวกรรมเครื่องกลเรือ)',
    degree_abbr_th: 'วศ.บ. (วิศวกรรมเครื่องกลเรือ)',
    degree_full_en: 'Bachelor of Engineering (Marine Engineering)',
    degree_abbr_en: 'B.Eng. (Marine Engineering)',
    degree_th: 'ปริญญาตรี', degree_en: 'Bachelor', duration_years: 4, total_credits: 148, level: 'ปวช./ม.6',
    career_path: 'นายประจำเรือฝ่ายช่างกล\nเจ้าพนักงานตรวจเรือ\nวิศวกรซ่อมบำรุง\nวิศวกรโครงการ',
    program_format: 'รูปแบบ : หลักสูตรระดับปริญญาตรี หลักสูตร 4 ปี\nประเภทของหลักสูตร : หลักสูตรทางวิชาชีพ\nภาษาที่ใช้ : ภาษาไทยและภาษาอังกฤษ โดยใช้ภาษาอังกฤษไม่น้อยกว่าร้อยละ 50\nการรับเข้าศึกษา : นักศึกษาไทย และ/หรือ นักศึกษาต่างชาติที่เข้าใจภาษาไทยเป็นอย่างดี\nความร่วมมือกับสถาบันอื่น : เป็นหลักสูตรเฉพาะของมหาวิทยาลัยที่มีความร่วมมือทางการศึกษากับหน่วยงานต่างๆ\nการให้ปริญญา : ให้ปริญญาเพียงสาขาวิชาเดียว',
    image_url: 'https://eng.rmutsv.ac.th/ruts/wp-content/uploads/2024/05/marine-1.png',
    is_active: true, is_featured: false, sort_order: 70
  },
  {
    faculty_id: 1,
    title_th: 'หลักสูตรอุตสาหกรรมศาสตรบัณฑิต สาขาวิชาเทคโนโลยีเครื่องกล (ต่อเนื่อง)',
    title_en: 'Bachelor of Industrial Technology Program in Mechanical Technology (Continuing Program)',
    degree_full_th: 'อุตสาหกรรมศาสตรบัณฑิต (เทคโนโลยีเครื่องกล)',
    degree_abbr_th: 'อส.บ. (เทคโนโลยีเครื่องกล)',
    degree_full_en: 'Bachelor of Industrial Technology (Mechanical Technology)',
    degree_abbr_en: 'B. Ind. Tech. (Mechanical Technology)',
    degree_th: 'ปริญญาตรี', degree_en: 'Bachelor', duration_years: 2, total_credits: 75, level: 'ปวส.',
    career_path: 'พนักงานควบคุมหม้อไอน้ำ เครื่องทำความเย็น และเครื่องจักรในโรงงานอุตสาหกรรม\nพนักงานฝ่ายซ่อมและบำรุงรักษาเครื่องจักร\nรับราชการและพนักงานในรัฐวิสาหกิจที่เกี่ยวข้องกับงานเครื่องกล\nพนักงานในอุตสาหกรรมและศูนย์บริการยานยนต์ไฟฟ้า\nพนักงานเขียนแบบและออกแบบด้านเครื่องกล\nผู้สอนในสถาบันการศึกษา\nอาชีพอิสระในงานเครื่องกล',
    program_format: 'รูปแบบ : หลักสูตรระดับปริญญาตรี (ต่อเนื่อง)\nประเภทของหลักสูตร : หลักสูตรปฏิบัติการ\nภาษาที่ใช้ : ภาษาไทยและภาษาอังกฤษ โดยใช้ภาษาอังกฤษไม่น้อยกว่าร้อยละ 50\nการรับเข้าศึกษา : รับนักศึกษาไทย และ/หรือ นักศึกษาต่างชาติ\nความร่วมมือกับสถาบันอื่น : เป็นหลักสูตรเฉพาะของมหาวิทยาลัย\nการให้ปริญญา : ให้ปริญญาเพียงสาขาวิชาเดียว',
    image_url: 'https://eng.rmutsv.ac.th/ruts/wp-content/uploads/2024/04/mechanical-technology.jpg',
    is_active: true, is_featured: false, sort_order: 80
  },
  {
    faculty_id: 1,
    title_th: 'หลักสูตรวิศวกรรมศาสตรบัณฑิต สาขาวิชาวิศวกรรมโยธา',
    title_en: 'Bachelor of Engineering Program in Civil Engineering',
    degree_full_th: 'วิศวกรรมศาสตรบัณฑิต (วิศวกรรมโยธา)',
    degree_abbr_th: 'วศ.บ. (วิศวกรรมโยธา)',
    degree_full_en: 'Bachelor of Engineering (Civil Engineering)',
    degree_abbr_en: 'B.Eng. (Civil Engineering)',
    degree_th: 'ปริญญาตรี', degree_en: 'Bachelor', duration_years: 4, total_credits: 149, level: 'ปวช./ม.6',
    career_path: 'ผู้ประกอบการทางด้านวิศวกรรมโยธา\nวิศวกรโยธาประจำหน่วยงานรัฐบาล\nวิศวกรโยธาประจำหน่วยงานรัฐวิสาหกิจ\nวิศวกรโยธาประจำบริษัทเอกชน',
    program_format: 'รูปแบบ : หลักสูตรระดับปริญญาตรี หลักสูตร 4 ปี\nประเภทของหลักสูตร : หลักสูตรทางวิชาชีพ\nภาษาที่ใช้ : ภาษาไทยและภาษาอังกฤษ โดยใช้ภาษาอังกฤษไม่น้อยกว่าร้อยละ 50\nการรับเข้าศึกษา : รับนักศึกษาไทย และ/หรือ นักศึกษาต่างชาติ\nความร่วมมือกับสถาบันอื่น : เป็นหลักสูตรเฉพาะของมหาวิทยาลัย\nการให้ปริญญา : ให้ปริญญาเพียงสาขาวิชาเดียว',
    image_url: 'https://eng.rmutsv.ac.th/ruts/wp-content/uploads/2024/04/BannerCivil.jpg',
    is_active: true, is_featured: false, sort_order: 90
  },
  {
    faculty_id: 1,
    title_th: 'หลักสูตรวิศวกรรมศาสตรบัณฑิต สาขาวิชาวิศวกรรมโยธา วิชาเอกวิศวกรรมโยธาระบบราง',
    title_en: 'Bachelor of Engineering Program in Civil Engineering (Railway Civil Engineering)',
    degree_full_th: 'วิศวกรรมศาสตรบัณฑิต (วิศวกรรมโยธา)',
    degree_abbr_th: 'วศ.บ. (วิศวกรรมโยธา)',
    degree_full_en: 'Bachelor of Engineering (Civil Engineering)',
    degree_abbr_en: 'B.Eng. (Civil Engineering)',
    degree_th: 'ปริญญาตรี', degree_en: 'Bachelor', duration_years: 4, total_credits: 149, level: 'ปวช./ม.6',
    career_path: 'ผู้ประกอบการทางด้านวิศวกรรมโยธา/วิศวกรรมโยธาระบบราง\nวิศวกรโยธาประจำหน่วยงานรัฐบาล\nวิศวกรโยธาประจำหน่วยงานรัฐวิสาหกิจ\nวิศวกรโยธาประจำบริษัทเอกชน',
    program_format: 'รูปแบบ : หลักสูตรระดับปริญญาตรี หลักสูตร 4 ปี\nประเภทของหลักสูตร : หลักสูตรทางวิชาชีพ\nภาษาที่ใช้ : ภาษาไทยและภาษาอังกฤษ โดยใช้ภาษาอังกฤษไม่น้อยกว่าร้อยละ 50\nการรับเข้าศึกษา : รับนักศึกษาไทย และ/หรือ นักศึกษาต่างชาติ\nความร่วมมือกับสถาบันอื่น : เป็นหลักสูตรเฉพาะของมหาวิทยาลัย ที่มีความร่วมมือทางการศึกษา\nการให้ปริญญา : ให้ปริญญาเพียงสาขาวิชาเดียว',
    image_url: 'https://eng.rmutsv.ac.th/ruts/wp-content/uploads/2024/04/S__4677649-scaled.jpg',
    is_active: true, is_featured: false, sort_order: 100
  },
  {
    faculty_id: 1,
    title_th: 'หลักสูตรวิศวกรรมศาสตรบัณฑิต สาขาวิชาวิศวกรรมสำรวจ',
    title_en: 'Bachelor of Engineering Program in Survey Engineering',
    degree_full_th: 'วิศวกรรมศาสตรบัณฑิต (วิศวกรรมสำรวจ)',
    degree_abbr_th: 'วศ.บ. (วิศวกรรมสำรวจ)',
    degree_full_en: 'Bachelor of Engineering (Survey Engineering)',
    degree_abbr_en: 'B.Eng. (Survey Engineering)',
    degree_th: 'ปริญญาตรี', degree_en: 'Bachelor', duration_years: 4, total_credits: 132, level: 'ปวช./ม.6',
    career_path: 'วิศวกรสำรวจ\nวิศวกรรังวัด\nนักวิชาการภูมิสารสนเทศ\nนักวิชาการแผนที่ภาพถ่าย\nเจ้าหน้าที่จัดทำแผนที่ภาษี\nเจ้าหน้าที่พัฒนาที่ดินและทรัพย์สิน',
    program_format: 'รูปแบบ : หลักสูตรระดับปริญญาตรี หลักสูตร 4 ปี\nประเภทของหลักสูตร : หลักสูตรทางวิชาชีพ\nภาษาที่ใช้ : ภาษาไทยและภาษาอังกฤษ โดยใช้ภาษาอังกฤษไม่น้อยกว่าร้อยละ 50\nการรับเข้าศึกษา : นักศึกษาไทย และ/หรือ นักศึกษาต่างชาติ\nความร่วมมือกับสถาบันอื่น : เป็นหลักสูตรเฉพาะของมหาวิทยาลัย\nการให้ปริญญา : ให้ปริญญาเพียงสาขาวิชาเดียว',
    image_url: 'https://eng.rmutsv.ac.th/ruts/wp-content/uploads/2024/04/survey.jpg',
    is_active: true, is_featured: false, sort_order: 110
  }
];

function post(data) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(data);
    const opts = {
      hostname: 'localhost', port: 1880,
      path: '/api/courses', method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + TOKEN,
        'Content-Length': Buffer.byteLength(body)
      }
    };
    const req = http.request(opts, res => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => resolve({ status: res.statusCode, body: d }));
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

(async () => {
  for (const c of courses) {
    const r = await post(c);
    const ok = r.status === 200 || r.status === 201;
    console.log(ok ? '✓' : '✗', c.title_th.substring(0, 40), r.status);
  }
  console.log('\nDone inserting', courses.length, 'courses');
})();

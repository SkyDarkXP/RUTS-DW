# RUTS Course Management System

ระบบจัดการหลักสูตร มหาวิทยาลัยเทคโนโลยีราชมงคลศรีวิชัย

## 🚀 วิธีเริ่มต้นใช้งาน

```bash
docker compose up -d --build
```

รอประมาณ **3-5 นาที** ให้ระบบ build เสร็จสมบูรณ์

---

## 🌐 URLs

| บริการ         | URL                              | คำอธิบาย           |
|---------------|----------------------------------|--------------------|
| 🖥️ Frontend   | http://localhost:4200            | หน้าเว็บหลัก       |
| 👤 Admin      | http://localhost:4200/admin      | จัดการหลักสูตร     |
| 🔑 Login      | http://localhost:4200/login      | เข้าสู่ระบบ Admin  |
| ⚙️ Node-RED   | http://localhost:1880/nodered    | Backend Editor     |
| 🗄️ phpMyAdmin | http://localhost:8080            | จัดการ Database    |

---

## 🔐 ข้อมูลเข้าสู่ระบบ

### Admin Web
- **username:** `admin`
- **password:** `admin123`

### phpMyAdmin
- **username:** `root`
- **password:** `rootpassword`

### Node-RED Editor
- **username:** `admin`
- **password:** `password` (SHA-256 in settings.js)

---

## 📋 สถาปัตยกรรม

```
┌─────────────────┐     ┌──────────────────┐
│  Angular 17     │────▶│    Node-RED       │
│  (Port 4200)    │     │    (Port 1880)    │
│  nginx proxy    │     │    REST API + JWT │
└─────────────────┘     └────────┬─────────┘
                                 │
                         ┌───────▼─────────┐
                         │   MySQL 8.0     │
                         │   (Port 3306)   │
                         └───────┬─────────┘
                                 │
                         ┌───────▼─────────┐
                         │  phpMyAdmin     │
                         │  (Port 8080)    │
                         └─────────────────┘
```

---

## 🔌 REST API Endpoints

| Method | Endpoint                    | Auth | คำอธิบาย              |
|--------|-----------------------------|------|-----------------------|
| POST   | /api/auth/login             | ❌   | เข้าสู่ระบบ           |
| GET    | /api/courses                | ❌   | ดึงหลักสูตรทั้งหมด   |
| GET    | /api/courses/:id            | ❌   | ดึงหลักสูตรตาม ID    |
| POST   | /api/courses                | ✅   | เพิ่มหลักสูตร         |
| PUT    | /api/courses/:id            | ✅   | แก้ไขหลักสูตร        |
| DELETE | /api/courses/:id            | ✅   | ลบหลักสูตร           |
| GET    | /api/faculties              | ❌   | ดึงคณะทั้งหมด         |
| POST   | /api/faculties              | ✅   | เพิ่มคณะ              |
| PUT    | /api/faculties/:id          | ✅   | แก้ไขคณะ             |
| DELETE | /api/faculties/:id          | ✅   | ลบคณะ                |
| GET    | /api/admin/courses          | ✅   | ดึงหลักสูตรทั้งหมด (admin) |

✅ = ต้องใช้ JWT Token ใน Header: `Authorization: Bearer <token>`

---

## 🛠️ การตั้งค่า

แก้ไขไฟล์ `.env` เพื่อปรับค่าต่างๆ:

```env
MYSQL_ROOT_PASSWORD=rootpassword
MYSQL_DATABASE=ruts_db
MYSQL_USER=ruts_user
MYSQL_PASSWORD=ruts_password
JWT_SECRET=ruts_jwt_super_secret_2024
```

---

## 📦 Technology Stack

- **Frontend:** Angular 17 + SCSS
- **Backend:** Node-RED (REST API + JWT)
- **Database:** MySQL 8.0
- **DB Management:** phpMyAdmin
- **Proxy:** Nginx
- **Containerization:** Docker + Docker Compose
- **Authentication:** JWT (jsonwebtoken + bcryptjs)

---

## 🔄 คำสั่งที่ใช้บ่อย

```bash
# เริ่มระบบ
docker compose up -d --build

# หยุดระบบ
docker compose down

# ดู logs
docker compose logs -f

# รีสตาร์ท service เดียว
docker compose restart node-red

# ลบข้อมูลทั้งหมด (รวม database)
docker compose down -v
```

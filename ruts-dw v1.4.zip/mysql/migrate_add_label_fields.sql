-- Migration: เพิ่ม column label สำหรับ faculty_staff และ study_plan
-- รันคำสั่งนี้บน DB ที่สร้างไปแล้ว (ไม่ใช่ DB ใหม่)

ALTER TABLE courses
  ADD COLUMN IF NOT EXISTS faculty_staff_label VARCHAR(500) NULL AFTER faculty_staff,
  ADD COLUMN IF NOT EXISTS study_plan_label VARCHAR(500) NULL AFTER study_plan_url;

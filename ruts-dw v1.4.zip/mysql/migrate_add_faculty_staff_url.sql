-- Migration: เพิ่ม column faculty_staff_url สำหรับ courses
USE ruts_db;

ALTER TABLE courses
  ADD COLUMN IF NOT EXISTS faculty_staff_url VARCHAR(500) NULL AFTER faculty_staff_label;

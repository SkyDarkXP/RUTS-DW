USE ruts_db;
-- View count column
ALTER TABLE courses ADD COLUMN IF NOT EXISTS view_count INT DEFAULT 0;

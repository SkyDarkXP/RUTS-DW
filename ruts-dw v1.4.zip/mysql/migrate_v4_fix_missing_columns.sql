-- Migration v4: เพิ่ม column ที่อาจขาดหายในระบบที่อัปเกรดมาจากเวอร์ชันเก่า
-- รองรับ MySQL 8.0 ทุก version ผ่าน stored procedure
USE ruts_db;

DROP PROCEDURE IF EXISTS add_column_if_missing;

DELIMITER //
CREATE PROCEDURE add_column_if_missing()
BEGIN
  -- faculty_staff_label
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = 'ruts_db' AND TABLE_NAME = 'courses' AND COLUMN_NAME = 'faculty_staff_label'
  ) THEN
    ALTER TABLE courses ADD COLUMN faculty_staff_label TEXT NULL AFTER faculty_staff;
  END IF;

  -- faculty_staff_url
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = 'ruts_db' AND TABLE_NAME = 'courses' AND COLUMN_NAME = 'faculty_staff_url'
  ) THEN
    ALTER TABLE courses ADD COLUMN faculty_staff_url TEXT NULL AFTER faculty_staff_label;
  END IF;

  -- study_plan_label
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = 'ruts_db' AND TABLE_NAME = 'courses' AND COLUMN_NAME = 'study_plan_label'
  ) THEN
    ALTER TABLE courses ADD COLUMN study_plan_label TEXT NULL AFTER study_plan_url;
  END IF;

  -- widen existing URL/label columns from VARCHAR(500) to TEXT
  ALTER TABLE courses
    MODIFY COLUMN study_plan_url TEXT NULL,
    MODIFY COLUMN study_plan_label TEXT NULL,
    MODIFY COLUMN faculty_staff_url TEXT NULL,
    MODIFY COLUMN faculty_staff_label TEXT NULL,
    MODIFY COLUMN image_url TEXT NULL,
    MODIFY COLUMN badge_color VARCHAR(50) DEFAULT '#e53935';

  -- view_count
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = 'ruts_db' AND TABLE_NAME = 'courses' AND COLUMN_NAME = 'view_count'
  ) THEN
    ALTER TABLE courses ADD COLUMN view_count INT DEFAULT 0;
  END IF;

  -- faculties.code
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = 'ruts_db' AND TABLE_NAME = 'faculties' AND COLUMN_NAME = 'code'
  ) THEN
    ALTER TABLE faculties ADD COLUMN code VARCHAR(50) NULL AFTER name_en;
  END IF;
END //
DELIMITER ;

CALL add_column_if_missing();
DROP PROCEDURE IF EXISTS add_column_if_missing;

SELECT 'Migration v4 complete' AS status;

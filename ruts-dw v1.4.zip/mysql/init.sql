-- RUTS Course Management System - Database Init
CREATE DATABASE IF NOT EXISTS ruts_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ruts_db;

-- Admin users table
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(200),
  role ENUM('admin','editor') DEFAULT 'admin',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Faculties/Departments table
CREATE TABLE IF NOT EXISTS faculties (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name_th VARCHAR(200) NOT NULL,
  name_en VARCHAR(200),
  code VARCHAR(50),
  description TEXT,
  is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Courses table
CREATE TABLE IF NOT EXISTS courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  faculty_id INT,
  title_th VARCHAR(300) NOT NULL,
  title_en VARCHAR(300),
  degree_full_th VARCHAR(300),
  degree_abbr_th VARCHAR(100),
  degree_full_en VARCHAR(300),
  degree_abbr_en VARCHAR(100),
  major VARCHAR(255),
  degree_th VARCHAR(100) DEFAULT 'ปริญญาตรี',
  degree_en VARCHAR(100) DEFAULT 'Bachelor',
  duration_years INT DEFAULT 4,
  total_credits INT DEFAULT NULL,
  level VARCHAR(50) DEFAULT 'ป.ตรี',
  program_format TEXT,
  faculty_staff TEXT,
  faculty_staff_label TEXT,
  faculty_staff_url TEXT,
  study_plan_url TEXT,
  study_plan_label TEXT,
  contact_info TEXT,
  description TEXT,
  requirements TEXT,
  career_path TEXT,
  image_url TEXT,
  badge_color VARCHAR(50) DEFAULT '#e53935',
  is_active TINYINT(1) DEFAULT 1,
  is_featured TINYINT(1) DEFAULT 0,
  sort_order INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (faculty_id) REFERENCES faculties(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default admin user (password: admin123, bcrypt hashed)
INSERT INTO users (username, password_hash, full_name, role) VALUES
('admin', '$2b$10$QQZ4fw1.7pkofZhEdiv.ZuSbL6tl4uQ4TI8jMO1SrF.QsD4DJdgSe', 'ผู้ดูแลระบบ', 'admin')
ON DUPLICATE KEY UPDATE username=username;

-- Sample faculties
INSERT INTO faculties (name_th, name_en, code) VALUES
('คณะวิศวกรรมศาสตร์', 'Faculty of Engineering', 'ENG'),
('คณะวิทยาศาสตร์และเทคโนโลยี', 'Faculty of Science and Technology', 'SCI'),
('คณะสถาปัตยกรรมศาสตร์', 'Faculty of Architecture', 'ARCH')
ON DUPLICATE KEY UPDATE name_th=name_th;

-- Sample courses
INSERT INTO courses (faculty_id, title_th, title_en, degree_th, duration_years, level, description, requirements, image_url, is_active, is_featured) VALUES
(1, 'วิศวกรรมคอมพิวเตอร์', 'Computer Engineering', 'ปริญญาตรี', 4, 'ป.ตรี ม.6',
'หลักสูตรวิศวกรรมคอมพิวเตอร์ มุ่งเน้นการผลิตบัณฑิตที่มีความรู้ความสามารถด้านวิศวกรรมคอมพิวเตอร์ ทั้งด้านฮาร์ดแวร์และซอฟต์แวร์',
'เป็นผู้สำเร็จการศึกษาระดับประกาศนียบัตรวิชาชีพชั้นสูง (ปวส.) ประเภทวิชาอุตสาหกรรม สาขาวิชาช่างเทคโนโลยีคอมพิวเตอร์ ช่างคอมพิวเตอร์ฮาร์ดแวร์ หรือสาขาที่เกี่ยวข้องกับคอมพิวเตอร์',
'https://images.unsplash.com/photo-1518770660439-4636190af475?w=400&q=80', 1, 1),
(1, 'วิศวกรรมโยธา', 'Civil Engineering', 'ปริญญาตรี', 4, 'ป.ตรี',
'หลักสูตรวิศวกรรมโยธา เน้นการออกแบบและก่อสร้างโครงสร้างพื้นฐาน สะพาน อาคาร และระบบสาธารณูปโภค',
'เป็นผู้สำเร็จการศึกษาระดับ ปวส. สาขาวิชาช่างก่อสร้าง ช่างโยธา หรือสาขาที่เกี่ยวข้อง',
'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=400&q=80', 1, 1),
(2, 'เทคโนโลยีสารสนเทศ', 'Information Technology', 'ปริญญาตรี', 4, 'ป.ตรี ม.6',
'หลักสูตรเทคโนโลยีสารสนเทศ มุ่งเน้นการพัฒนาระบบสารสนเทศ การพัฒนาซอฟต์แวร์ และการจัดการฐานข้อมูล',
'เป็นผู้สำเร็จการศึกษาระดับมัธยมศึกษาตอนปลาย (ม.6) หรือ ปวส. สาขาที่เกี่ยวข้อง',
'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=400&q=80', 1, 0);

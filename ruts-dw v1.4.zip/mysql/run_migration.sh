#!/bin/bash
# รัน migration เพิ่ม column faculty_staff_label และ study_plan_label
# ใช้สำหรับ DB ที่สร้างไปแล้วก่อนเวอร์ชัน v0.5

set -e

# โหลด .env ถ้ามี
if [ -f "$(dirname "$0")/../.env" ]; then
  export $(grep -v '^#' "$(dirname "$0")/../.env" | xargs)
fi

DB=${MYSQL_DATABASE:-ruts_db}
USER=${MYSQL_USER:-ruts_user}
PASS=${MYSQL_PASSWORD:-ruts_password}

echo ">> Running migration on database: $DB"

docker exec -i ruts_mysql mysql -u"$USER" -p"$PASS" "$DB" << 'SQL'
ALTER TABLE courses
  ADD COLUMN IF NOT EXISTS faculty_staff_label VARCHAR(500) NULL AFTER faculty_staff,
  ADD COLUMN IF NOT EXISTS study_plan_label VARCHAR(500) NULL AFTER study_plan_url;
SQL

echo ">> Migration complete!"

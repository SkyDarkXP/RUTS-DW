-- Migration v3.0: Campus, View Count, Audit Log
-- Run: mysql -u root -p ruts_db < migrate_v3_0.sql

USE ruts_db;

-- Add campus field to courses
ALTER TABLE courses
  ADD COLUMN campus VARCHAR(100) DEFAULT NULL AFTER faculty_id,
  ADD COLUMN view_count INT DEFAULT 0 AFTER sort_order;

-- Add campus field to faculties
ALTER TABLE faculties
  ADD COLUMN campus VARCHAR(100) DEFAULT NULL AFTER code;

-- Audit log table
CREATE TABLE IF NOT EXISTS audit_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  username VARCHAR(100),
  action VARCHAR(50) NOT NULL,          -- create | update | delete | import | export
  entity_type VARCHAR(50) NOT NULL,     -- course | faculty | user | backup
  entity_id INT,
  entity_name VARCHAR(300),
  detail TEXT,
  ip_address VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_created (created_at),
  INDEX idx_user (username),
  INDEX idx_entity (entity_type, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Search keywords log (for analytics)
CREATE TABLE IF NOT EXISTS search_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  keyword VARCHAR(300),
  result_count INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_keyword (keyword),
  INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Update existing courses with sample campus data
UPDATE courses SET campus = 'สงขลา' WHERE id IN (SELECT id FROM (SELECT id FROM courses LIMIT 5) t);
UPDATE courses SET campus = 'ตรัง' WHERE campus IS NULL LIMIT 3;
UPDATE courses SET campus = 'นครศรีธรรมราช' WHERE campus IS NULL LIMIT 2;
